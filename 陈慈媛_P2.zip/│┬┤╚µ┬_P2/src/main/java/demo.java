import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * 数据库连接
 */
public class demp {
    public static void main(String[] args) {
        Connection con;
        //jdbc驱动
        String driver="com.mysql.cj.jdbc.Driver";
        String url="jdbc:mysql://localhost:3306/demo?&useSSL=false&serverTimezone=UTC";
        String user="root";
        String password="root";
        try {
            //注册JDBC驱动程序
            Class.forName(driver);
            //建立连接
            con = DriverManager.getConnection(url, user, password);
            if (!con.isClosed()) {
                System.out.println("数据库连接成功");
            }
            con.close();
        } catch (ClassNotFoundException e) {
            System.out.println("数据库驱动没有安装");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("数据库连接失败");
        }
    }
}
    public static void Close(ResultSet resultset, Connection conn, Statement statement){

        //7.关闭连接
        if (resultset!=null){
            try{
                resultset.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        if(conn!=null){
            try{
                conn.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(statement!=null) {
            try{
                statement.close();
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
public class TestConnection {

    public static void main(String args[])
    {
        Statement statement=null;
        ResultSet resultset=null;
        Connection conn=null;
        try {
            //调用Getconnection()方法：1.加载驱动2.创建连接
            conn = DButil.Getconnection();
            //3.sql语句
            String sql="select * from users";
            //4.得到statement对象
            statement = conn.prepareStatement(sql);
            //5.执行sql
            resultset = statement.executeQuery(sql);
            // 6.处理结果集
            while(resultset.next())
            {
                System.out.println("user_id: "+resultset.getString(1));
                System.out.println("user_name: "+resultset.getString(2));
                System.out.println("phone: "+resultset.getString(3));
                System.out.println("           ");
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            //7.关闭连接
            DButil.Close(resultset, conn, statement);
        }
    }
    public class TestConnection {

        public List<Users> FindAll(){

            Statement statement=null, statementadd,statementdel,statementupdate=null;
            ResultSet resultset = null;
            Connection conn = null;
            List<Users> list = new ArrayList<>();
            try {
                //1.加载驱动2.创建连接
                conn = DButil.Getconnection();

                //3.sql语句 增、删、改、查
                String addsql="insert into users(user_id,user_name)  values('0121812530721','杨洋');";
                String delsql="delete from users where user_id='0121610870327'";
                String updatasql="update users set user_name='刘翔' where user_id='1234567890123'";
                String sql = "select * from users";

                //4.得到statement对象
                statementadd = conn.prepareStatement(addsql);
                statementdel=conn.prepareStatement(delsql);
                statementupdate=conn.prepareStatement(updatasql);
                statement = conn.prepareStatement(sql);

                //5.执行sql
                ((PreparedStatement) statementadd).executeUpdate();
                ((PreparedStatement) statementdel).executeUpdate();
                ((PreparedStatement) statementupdate).executeUpdate();
                //执行过增加、删除、修改后，最后再查询
                resultset = ((PreparedStatement) statement).executeQuery();

                // 6.处理结果集
                while (resultset.next()) {
                    String id = resultset.getString(1);//获得user_id
                    String name = resultset.getString(2);//获得user_name
                    Users users = new Users(id, name);//创建新的Users对象
                    list.add(users);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                DButil.Close(resultset, conn, statement);
            }
            return list;
        }

        public static void main(String args[]) {
            //定义数据表
            List<Users> list = new ArrayList<>();
            //创建 TestConnection 对象testConnection
            TestConnection testConnection =new TestConnection();
            //调用FindAll()获得查询的数据表
            list=testConnection.FindAll();
            //输出数据表中的数据
            System.out.println(list.toString());
        }
    }

